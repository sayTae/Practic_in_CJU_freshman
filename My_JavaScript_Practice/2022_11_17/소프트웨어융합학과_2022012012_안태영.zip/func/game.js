var context; // 변수 선언
var velocity;
var angle;
var ballV;
var ballVx;
var ballVy;
var ballX = 10;
var ballY = 250;
var ballRadius = 10;
var score = 0;
var image = new Image();
image.src = "./imgs/lawn.png";
var backimage = new Image();
backimage.src = "./imgs/net.png";
var timer;

function drawBall() {
  // 공을 화면에 그림
  context.beginPath();
  context.arc(ballX, ballY, ballRadius, 0, 2.0 * Math.PI, true);
  context.fillStyle = "red";
  context.fill();
}
function drawBackground() {
  // 배경을 화면에 그림
  context.drawImage(image, 0, 270);
  context.drawImage(backimage, 450, 60);
}
function draw() {
  // 전체 화면을 그리는 함수
  context.clearRect(0, 0, 500, 300);
  drawBall();
  drawBackground();
}
function init() {
  // 초기화하는 함수
  ballX = 10;
  ballY = 250;
  ballRadius = 10;
  context = document.getElementById("canvas").getContext("2d");
  draw();
}
function start() {
  // 사용자가 발사 버튼을 누르면 호출
  init();
  velocity = Number(document.getElementById("velocity").value);
  angle = Number(document.getElementById("angle").value);
  var angleR = (angle * Math.PI) / 100;

  ballVx = velocity * Math.cos(angleR);
  ballVy = -velocity * Math.sin(angleR);

  draw();
  timer = setInterval(calculate, 100);
  return false;
}
function calculate() {
  // 공의 현재 속도와 위치를 업데이트 함
  ballVy = ballVy + 1.98;
  ballX = ballX + ballVx;
  ballY = ballY + ballVy;

  if (ballX >= 450 && ballX <= 480 && ballY >= 60 && ballY <= 210) {
    score++;
    document.getElementById("score").innerHTML = "점수: " + score;
    clearInterval(timer);
  }
  if (ballY >= 300 || ballY < 0) {
    clearInterval(timer);
  }
  draw();
}
